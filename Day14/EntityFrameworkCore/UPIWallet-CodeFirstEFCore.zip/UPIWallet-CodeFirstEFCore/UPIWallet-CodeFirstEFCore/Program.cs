﻿using System;

namespace UPIWallet_CodeFirstEFCore
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
